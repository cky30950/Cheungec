/* ============================================================
 * POST /api/wallet/payment
 * ------------------------------------------------------------
 * 員工以病人儲值餘額支付診症帳單。
 * 冪等鍵由伺服器強制為 pay:{consultationId}，客戶端無需傳送；
 * 金額須與診症單 billingItemsStructured 重算的應收總額一致。
 * 請求：{ patientId, amount, consultationId, appointmentId? }
 * 回應：{ ok, chargedAmount, balance, bonusBalance,
 *         fromBalance, fromBonus, txId }
 * 餘額不足回 402 INSUFFICIENT_FUNDS；重複扣款回 409 WALLET_ALREADY_PAID。
 * ============================================================ */

import { walletPayment } from './lib/wallet-store.js';
import {
    requireStaff,
    readJsonBody,
    parsePatientId,
    resolveClinicId,
    jsonResponse,
    optionsResponse,
    toErrorResponse
} from './lib/http.js';

export const onRequestOptions = () => optionsResponse();

export async function onRequestPost(context) {
    const { request, env } = context;
    try {
        const claims = await requireStaff(request, env);
        const body = await readJsonBody(request);
        const patientId = parsePatientId(body);
        const amount = Number(body.amount);
        if (!Number.isFinite(amount) || amount <= 0 || amount > 100000) {
            return jsonResponse({
                error: 'INVALID_AMOUNT',
                message: '付款金額必須大於 0 且不超過 HK$100,000'
            }, 400);
        }
        const consultationId = String(body.consultationId || '').trim();
        if (!consultationId) {
            return jsonResponse({
                error: 'MISSING_CONSULTATION',
                message: '缺少 consultationId'
            }, 400);
        }
        const clinicId = resolveClinicId(claims, body);
        const result = await walletPayment(env, claims, {
            clinicId,
            patientId,
            amount,
            consultationId,
            appointmentId: body.appointmentId ? String(body.appointmentId) : ''
        });
        return jsonResponse(result);
    } catch (error) {
        return toErrorResponse(error);
    }
}
